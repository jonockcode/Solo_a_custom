# Solo

> [!IMPORTANT]
> This repo is synced automatically with the [TryGhost/Themes](https://github.com/TryGhost/Themes) monorepo. If you're looking to contribute or raise an issue, head over to the main repository [TryGhost/Themes](https://github.com/TryGhost/Themes) where our official themes are developed.

Solo is a minimal theme for [Ghost](https://github.com/TryGhost/Ghost) focused on showcasing the work of an individual writer or creator. This theme is highly customizable, with a few simple settings that allow you to quickly apply your own personal style to your site.

**Demo: https://solo.ghost.io**

# Instructions

1. [Download this theme](https://github.com/TryGhost/Solo/archive/main.zip)
2. Log into Ghost, and go to the `Design` settings area to upload the zip file

# Development

### Artikel ohne Artikelbild

Nach dem Hochladen und Aktivieren des Themes kann im Ghost-Editor unter
**Beitragseinstellungen → Template** die Vorlage **Ohne Artikelbild** ausgewählt
werden. Sie zeigt Titel, Auszug und Inhalt ohne das Artikelbild und dessen
Bildunterschrift an. Das hinterlegte Artikelbild bleibt für die Artikelübersicht
und Social-Media-Vorschauen verfügbar. Bilder im Artikelinhalt werden weiterhin
angezeigt. Die Standardvorlage bleibt unverändert.

Styles are compiled using Gulp/PostCSS to polyfill future CSS spec. You'll need [Node](https://nodejs.org/), [pnpm](https://pnpm.io/) and [Gulp](https://gulpjs.com) installed globally. After that, from the theme's root directory:

```bash
# Install
pnpm install

# Run build & watch for changes
pnpm dev
```

Now you can edit `/assets/css/` files, which will be compiled to `/assets/built/` automatically.

The `zip` Gulp task packages the theme files into `dist/solo.zip`, which you can then upload to your site.

```bash
pnpm zip
```

### Theme translations

Please see the @Tryghost/Themes/theme-translations/README.md for how to edit or contribute translations.

# Copyright & License

Copyright (c) 2013-2026 Ghost Foundation - Released under the [MIT license](LICENSE).
